/**
 *    ||          ____  _ __
 * +------+      / __ )(_) /_______________ _____  ___
 * | 0xBC |     / __  / / __/ ___/ ___/ __ `/_  / / _ \
 * +------+    / /_/ / / /_/ /__/ /  / /_/ / / /_/  __/
 *  ||  ||    /_____/_/\__/\___/_/   \__,_/ /___/\___/
 *
 * Crazyflie control firmware
 *
 * Copyright (C) 2011-2016 Bitcraze AB
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, in version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 * controller.h - Controller interface
 */
#ifndef __CONTROLLER_H__
#define __CONTROLLER_H__

#include "stabilizer_types.h"

typedef enum {
  ControllerTypeAutoSelect,
  ControllerTypePID,
  ControllerTypeMellinger,
  ControllerTypeINDI,
  ControllerTypeBrescianini,
  ControllerTypeLee,
  ControllerTypeGA_STT,
#ifdef CONFIG_CONTROLLER_OOT
  ControllerTypeOot,
#endif
  ControllerType_COUNT,
} ControllerType;

void controllerInit(ControllerType controller);
bool controllerTest(void);
void controller(control_t *control, const setpoint_t *setpoint,
                                         const sensorData_t *sensors,
                                         const state_t *state,
                                         const stabilizerStep_t stabilizerStep);
ControllerType controllerGetType(void);
const char* controllerGetName();


#ifdef CONFIG_CONTROLLER_OOT
void controllerOutOfTreeInit(void);
bool controllerOutOfTreeTest(void);
void controllerOutOfTree(control_t *control, const setpoint_t *setpoint, const sensorData_t *sensors, const state_t *state, const stabilizerStep_t stabilizerStep);
#endif

#endif //__CONTROLLER_H__
